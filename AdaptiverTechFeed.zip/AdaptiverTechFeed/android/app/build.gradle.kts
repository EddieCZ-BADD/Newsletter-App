plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.techfeed"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.example.techfeed"
        minSdk = 28  // JobInfo.Builder.setRequiredNetwork(NetworkRequest)
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
        // Release: eigene HTTPS-Serveradresse eintragen.
        buildConfigField("String", "FEED_URL", "\"https://example.invalid/feed\"")
    }

    buildTypes {
        getByName("debug") {
            // Standard-Android-Emulator -> Hostrechner/localhost
            buildConfigField("String", "FEED_URL", "\"http://10.0.2.2:8000/feed\"")
        }
    }

    buildFeatures {
        buildConfig = true
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation("com.android.volley:volley:1.2.1")
    implementation("androidx.recyclerview:recyclerview:1.4.0")
}
