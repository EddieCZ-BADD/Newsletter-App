package com.example.techfeed

import android.app.Activity
import android.app.job.JobInfo
import android.app.job.JobScheduler
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.TextView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.util.concurrent.Executors

/** MAPE-K: Monitor (Netz), Analyze (Bandbreite), Plan (Bilder an/aus),
 * Execute (Adapter), Knowledge (SQLite + aktueller Netzwerkzustand).
 */
class MainActivity : Activity() {
    companion object {
        private const val PREFETCH_JOB_ID = 1001
        private const val SLOW_CONNECTION_KBPS = 1_500 // Demonstrationsschwelle
    }

    private val io = Executors.newSingleThreadExecutor()
    private val foregroundTag = Any()
    private lateinit var adapter: FeedAdapter
    private lateinit var status: TextView
    private lateinit var connectivity: ConnectivityManager
    private var online = false

    // Dynamisch registriert; manifestbasierte CONNECTIVITY_ACTION-Empfänger
    // werden bei neuen Android-Versionen nicht zuverlässig ausgeliefert.
    private val networkReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            evaluateNetworkContext()
        }
    }

    // Ergänzt den BroadcastReceiver um Änderungen der Netzwerkfähigkeiten,
    // auch wenn sich nur die geschätzte Bandbreite verändert.
    private val networkCallback = object : ConnectivityManager.NetworkCallback() {
        override fun onAvailable(network: Network) = updateOnUiThread()
        override fun onLost(network: Network) = updateOnUiThread()
        override fun onCapabilitiesChanged(network: Network, caps: NetworkCapabilities) =
            updateOnUiThread()
    }

    private fun updateOnUiThread() {
        runOnUiThread {
            if (!isDestroyed) evaluateNetworkContext()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        connectivity = getSystemService(ConnectivityManager::class.java)
        status = findViewById(R.id.statusText)
        adapter = FeedAdapter(this)
        findViewById<RecyclerView>(R.id.feedList).apply {
            layoutManager = LinearLayoutManager(this@MainActivity)
            adapter = this@MainActivity.adapter
        }
        findViewById<Button>(R.id.refreshButton).setOnClickListener {
            if (online) refreshFeed() else status.text = "Offline – lokaler Feed bleibt verfügbar"
        }

        // Offline-First: SQLite wird angezeigt, bevor REST eine Antwort liefert.
        io.execute {
            try {
                val local = DatabaseHelper(applicationContext).use { it.readArticles() }
                runOnUiThread {
                    if (!isDestroyed) adapter.submitArticles(local)
                }
            } catch (error: Exception) {
                Log.e("MainActivity", "SQLite-Lesen fehlgeschlagen", error)
            }
        }
        scheduleWifiPrefetch()
    }

    override fun onStart() {
        super.onStart()
        registerReceiver(
            networkReceiver,
            IntentFilter(ConnectivityManager.CONNECTIVITY_ACTION)
        )
        connectivity.registerDefaultNetworkCallback(networkCallback)
        // Status sofort bestimmen, nicht auf ein Broadcast warten.
        evaluateNetworkContext()
    }

    override fun onStop() {
        // Kein dauerhaft laufender Receiver, keine Polling-Schleife.
        unregisterReceiver(networkReceiver)
        connectivity.unregisterNetworkCallback(networkCallback)
        NetworkManager.cancel(this, foregroundTag)
        online = false
        super.onStop()
    }

    override fun onDestroy() {
        io.shutdown()
        super.onDestroy()
    }

    private fun evaluateNetworkContext() {
        val activeNetwork = connectivity.activeNetwork
        val caps = activeNetwork?.let { connectivity.getNetworkCapabilities(it) }
        val nowOnline = caps?.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED) == true
        val downstream = caps?.linkDownstreamBandwidthKbps ?: 0
        val goodBandwidth = nowOnline && downstream >= SLOW_CONNECTION_KBPS

        adapter.setImagesEnabled(goodBandwidth)
        status.text = when {
            !nowOnline -> "Offline – SQLite-Inhalte"
            goodBandwidth -> "Online – Bilder aktiviert (~${downstream} kbit/s)"
            else -> "Langsames Netz – nur Texte (~${downstream} kbit/s)"
        }

        // Eventbasiertes Aktualisieren bei Wiederverbindung, kein Busy Waiting.
        if (nowOnline && !online) refreshFeed()
        online = nowOnline
    }

    private fun refreshFeed() {
        NetworkManager.fetchFeed(
            context = this,
            tag = foregroundTag,
            onSuccess = { articles ->
                // Bereits zerstörte Activities dürfen ihren Executor nicht mehr nutzen.
                if (!isDestroyed) io.execute {
                    try {
                        DatabaseHelper(applicationContext).use {
                            it.replaceArticles(articles)
                        }
                        runOnUiThread {
                            if (!isDestroyed) adapter.submitArticles(articles)
                        }
                    } catch (error: Exception) {
                        Log.e("MainActivity", "SQLite-Schreiben fehlgeschlagen", error)
                        runOnUiThread {
                            if (!isDestroyed) status.text = "Lokale Speicherung fehlgeschlagen"
                        }
                    }
                }
            },
            onError = { error ->
                Log.w("MainActivity", "REST nicht erreichbar; SQLite bleibt", error)
                status.text = "Netzwerkfehler – gespeicherte Artikel bleiben sichtbar"
            }
        )
    }

    private fun scheduleWifiPrefetch() {
        val scheduler = getSystemService(JobScheduler::class.java)
        if (scheduler.getPendingJob(PREFETCH_JOB_ID) != null) return

        // API >= 28: exakter WLAN-Transport statt nur NETWORK_TYPE_UNMETERED.
        val wifi = NetworkRequest.Builder()
            .addTransportType(NetworkCapabilities.TRANSPORT_WIFI)
            .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
            .addCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
            .build()
        val jobInfo = JobInfo.Builder(
            PREFETCH_JOB_ID,
            ComponentName(this, PrefetchJobService::class.java)
        )
            .setRequiredNetwork(wifi)
            .setPeriodic(60 * 60 * 1000L, 15 * 60 * 1000L)
            .setPrefetch(true)
            .build()
        if (scheduler.schedule(jobInfo) != JobScheduler.RESULT_SUCCESS) {
            Log.w("MainActivity", "WLAN-Prefetch-Job konnte nicht geplant werden")
        }
    }
}
