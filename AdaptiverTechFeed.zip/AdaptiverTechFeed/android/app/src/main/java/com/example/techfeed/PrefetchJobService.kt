package com.example.techfeed

import android.app.job.JobParameters
import android.app.job.JobService
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Handler
import android.os.Looper
import android.util.Log
import java.util.concurrent.Executors

/** JobScheduler führt WLAN-Prefetching aus, ohne eigene Wake Locks oder Polling. */
class PrefetchJobService : JobService() {
    private val io = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())

    // Der JobScheduler ruft Start/Stop auf dem Hauptthread auf.
    private class RunningJob(val params: JobParameters, val tag: Any) {
        @Volatile var stopped = false
    }

    private var running: RunningJob? = null

    override fun onStartJob(params: JobParameters): Boolean {
        // Volley nutzt die Standardnetzroute. Daher muss DIESE Route WLAN sein,
        // selbst wenn JobScheduler auch ein anderes WLAN-Netz matchen könnte.
        if (!hasActiveWifi()) return false

        val job = RunningJob(params, Any())
        running = job

        NetworkManager.fetchFeed(
            context = this,
            tag = job.tag,
            onSuccess = { articles ->
                // Volley-Callback: Hauptthread. SQLite niemals hier ausführen.
                io.execute {
                    var retry = false
                    try {
                        if (!job.stopped) {
                            DatabaseHelper(applicationContext).use { database ->
                                database.replaceArticles(articles)
                            }
                        }
                    } catch (error: Exception) {
                        Log.e("PrefetchJobService", "SQLite-Fehler", error)
                        retry = true
                    }
                    main.post { finishIfRunning(job, retry) }
                }
            },
            onError = { error ->
                Log.w("PrefetchJobService", "Feed-Prefetch fehlgeschlagen", error)
                finishIfRunning(job, true)
            }
        )
        return true // Asynchron! jobFinished() folgt erst NACH SQLite-Commit.
    }

    private fun hasActiveWifi(): Boolean {
        val connectivity = getSystemService(ConnectivityManager::class.java)
        val network = connectivity.activeNetwork ?: return false
        val caps = connectivity.getNetworkCapabilities(network) ?: return false
        return caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) &&
            caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
    }

    private fun finishIfRunning(job: RunningJob, retry: Boolean) {
        // Dieser Check und onStopJob() erfolgen beide auf dem Hauptthread.
        if (running !== job || job.stopped) return
        running = null
        jobFinished(job.params, retry)
    }

    override fun onStopJob(params: JobParameters): Boolean {
        val job = running
        if (job != null && job.params === params) {
            job.stopped = true
            running = null
            NetworkManager.cancel(this, job.tag)
        }
        // Unterbrochene Arbeit soll unter passenden Bedingungen erneut laufen.
        return true
    }

    override fun onDestroy() {
        running?.let {
            it.stopped = true
            NetworkManager.cancel(this, it.tag)
        }
        running = null
        io.shutdown() // Laufende SQLite-Transaktion darf atomar fertig werden.
        super.onDestroy()
    }
}
