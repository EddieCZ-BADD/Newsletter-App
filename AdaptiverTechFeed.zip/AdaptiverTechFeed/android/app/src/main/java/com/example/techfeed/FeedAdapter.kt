package com.example.techfeed

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.android.volley.toolbox.NetworkImageView

/** MAPE-K / Execute: REDUKTION durch Weglassen teurer Bild-Anforderungen. */
class FeedAdapter(context: Context) : RecyclerView.Adapter<FeedAdapter.ArticleHolder>() {
    private val imageLoader = NetworkManager.imageLoader(context)
    private val items = mutableListOf<Article>()
    private var imagesEnabled = false // Konservativer Start: keine Bildrequests ohne Kontextwissen.

    fun submitArticles(articles: List<Article>) {
        items.clear()
        items.addAll(articles)
        notifyDataSetChanged()
    }

    fun setImagesEnabled(enabled: Boolean) {
        if (imagesEnabled == enabled) return
        imagesEnabled = enabled
        notifyDataSetChanged() // Sichtbare Zeilen neu binden; alte Bildrequests abbrechen.
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ArticleHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_article, parent, false)
        return ArticleHolder(view)
    }

    override fun onBindViewHolder(holder: ArticleHolder, position: Int) {
        val article = items[position]
        holder.title.text = article.title
        holder.summary.text = article.summary

        // Lazy Evaluation: Erst bei guter Bandbreite wird überhaupt ein
        // Volley-ImageRequest durch NetworkImageView angestoßen.
        if (imagesEnabled && article.imageUrl.isNotBlank()) {
            holder.image.visibility = View.VISIBLE
            holder.image.setImageUrl(article.imageUrl, imageLoader)
        } else {
            holder.image.setImageUrl("", imageLoader) // Vorherige Requests canceln.
            holder.image.setImageBitmap(null)
            holder.image.visibility = View.GONE
        }
    }

    override fun getItemCount() = items.size

    class ArticleHolder(view: View) : RecyclerView.ViewHolder(view) {
        val title: TextView = view.findViewById(R.id.articleTitle)
        val summary: TextView = view.findViewById(R.id.articleSummary)
        val image: NetworkImageView = view.findViewById(R.id.articleImage)
    }
}
