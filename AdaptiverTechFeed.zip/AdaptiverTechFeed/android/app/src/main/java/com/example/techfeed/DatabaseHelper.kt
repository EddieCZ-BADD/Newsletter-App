package com.example.techfeed

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

/** Persistentes Offline-Knowledge (K): Artikel bleiben ohne HTTP-Cache abrufbar. */
data class Article(
    val id: String,
    val title: String,
    val summary: String,
    val imageUrl: String
)

class DatabaseHelper(context: Context) :
    SQLiteOpenHelper(context.applicationContext, DATABASE_NAME, null, DATABASE_VERSION) {

    companion object {
        private const val DATABASE_NAME = "tech_feed.db"
        private const val DATABASE_VERSION = 1
        private const val TABLE = "articles"
    }

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            """CREATE TABLE $TABLE (
                id TEXT PRIMARY KEY NOT NULL,
                title TEXT NOT NULL,
                summary TEXT NOT NULL,
                image_url TEXT NOT NULL,
                position INTEGER NOT NULL
            )""".trimIndent()
        )
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        // Nur für das Vorlesungs-Dummy-Projekt: in Produktion Daten migrieren!
        db.execSQL("DROP TABLE IF EXISTS $TABLE")
        onCreate(db)
    }

    /** Alles oder nichts: Ein neuer REST-Snapshot ersetzt atomar den alten Feed. */
    fun replaceArticles(articles: List<Article>) {
        val db = writableDatabase
        db.beginTransaction()
        try {
            db.delete(TABLE, null, null)
            articles.forEachIndexed { index, article ->
                val values = ContentValues().apply {
                    put("id", article.id)
                    put("title", article.title)
                    put("summary", article.summary)
                    put("image_url", article.imageUrl)
                    put("position", index)
                }
                db.insertOrThrow(TABLE, null, values)
            }
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
    }

    /** Offline-First: immer zuerst diesen lokalen Snapshot anzeigen. */
    fun readArticles(): List<Article> {
        val result = mutableListOf<Article>()
        readableDatabase.query(
            TABLE,
            arrayOf("id", "title", "summary", "image_url"),
            null, null, null, null, "position ASC"
        ).use { cursor ->
            while (cursor.moveToNext()) {
                result.add(
                    Article(
                        id = cursor.getString(0),
                        title = cursor.getString(1),
                        summary = cursor.getString(2),
                        imageUrl = cursor.getString(3)
                    )
                )
            }
        }
        return result
    }
}
