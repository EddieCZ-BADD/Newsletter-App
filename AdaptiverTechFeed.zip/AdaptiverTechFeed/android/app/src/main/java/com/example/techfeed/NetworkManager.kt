package com.example.techfeed

import android.content.Context
import android.graphics.Bitmap
import android.util.LruCache
import com.android.volley.Request
import com.android.volley.RequestQueue
import com.android.volley.VolleyError
import com.android.volley.toolbox.ImageLoader
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.Volley
import org.json.JSONException

/** Eine Volley-RequestQueue für Feed UND Bilder; Volley cached HTTP-Antworten. */
object NetworkManager {
    @Volatile private var queue: RequestQueue? = null
    @Volatile private var loader: ImageLoader? = null

    @Synchronized
    private fun initialize(context: Context) {
        if (queue != null) return

        val requestQueue = Volley.newRequestQueue(context.applicationContext)
        val bitmapCache = object : LruCache<String, Bitmap>(
            (Runtime.getRuntime().maxMemory() / 1024 / 8).toInt().coerceAtLeast(1024)
        ) {
            override fun sizeOf(key: String, bitmap: Bitmap): Int =
                (bitmap.byteCount / 1024).coerceAtLeast(1)
        }
        val imageCache = object : ImageLoader.ImageCache {
            override fun getBitmap(url: String): Bitmap? = bitmapCache.get(url)
            override fun putBitmap(url: String, bitmap: Bitmap) {
                bitmapCache.put(url, bitmap)
            }
        }
        loader = ImageLoader(requestQueue, imageCache)
        queue = requestQueue
    }

    fun imageLoader(context: Context): ImageLoader {
        initialize(context)
        return checkNotNull(loader)
    }

    fun cancel(context: Context, tag: Any) {
        initialize(context)
        queue?.cancelAll(tag)
    }

    /** REST-Abruf erfolgt asynchron; SQLite-Persistenz ist Sache des Aufrufers. */
    fun fetchFeed(
        context: Context,
        tag: Any,
        onSuccess: (List<Article>) -> Unit,
        onError: (VolleyError) -> Unit
    ) {
        initialize(context)
        val request = JsonObjectRequest(
            Request.Method.GET,
            BuildConfig.FEED_URL,
            null,
            { json ->
                try {
                    val items = json.getJSONArray("articles")
                    val articles = ArrayList<Article>(items.length())
                    for (i in 0 until items.length()) {
                        val item = items.getJSONObject(i)
                        articles.add(
                            Article(
                                id = item.getString("id"),
                                title = item.getString("title"),
                                summary = item.getString("summary"),
                                imageUrl = item.getString("image_url")
                            )
                        )
                    }
                    onSuccess(articles)
                } catch (error: JSONException) {
                    onError(com.android.volley.ParseError(error))
                }
            },
            onError
        )
        request.tag = tag
        request.setShouldCache(true) // Backend: Cache-Control: max-age=300
        checkNotNull(queue).add(request)
    }
}
