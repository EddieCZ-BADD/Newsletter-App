# Adaptiver Tech-Feed-Reader

Ein universitäres Offline-First-Demoprojekt auf Basis von **FastAPI + Volley + SQLiteOpenHelper + JobScheduler + BroadcastReceiver + RecyclerView**. Keine Coroutines, Room, Retrofit oder WorkManager.

## Dateien

- `backend/main.py` – REST-Proxy mit Dummy-Artikeln und `Cache-Control: max-age=300`.
- `android/app/src/main/java/com/example/techfeed/DatabaseHelper.kt` – SQLite-Snapshot als Offline-Quelle sowie `Article`-Datenklasse.
- `android/app/src/main/java/com/example/techfeed/NetworkManager.kt` – eine Volley-Queue, GET-JSON, Memory-Bitmap-Cache, HTTP-Disk-Cache.
- `android/app/src/main/java/com/example/techfeed/PrefetchJobService.kt` – WLAN-only periodisches Prefetching (JobScheduler).
- `android/app/src/main/java/com/example/techfeed/MainActivity.kt` – SQLite zuerst, Volley danach; Laufzeit-BroadcastReceiver + NetworkCallback; Job-Registrierung.
- `android/app/src/main/java/com/example/techfeed/FeedAdapter.kt` – RecyclerView und Bildreduktion bei geschätzter schlechter Bandbreite.
- Zusätzliche Startdateien: Gradle, Manifest, Debug-Manifest und zwei Android-XML-Layouts.

## Start des Servers

```bash
cd backend
python -m venv .venv
source .venv/bin/activate          # Windows: .venv\\Scripts\\activate
pip install -r requirements.txt
python main.py
curl -i http://127.0.0.1:8000/feed
```

## Android-App

1. Ordner `android/` in Android Studio öffnen, Android SDK API 35 und JDK 17 auswählen. Verwendete Gradle-Version: 8.11.1; das Repository enthält Konfigurationsdateien, aber keinen generierten Gradle-Wrapper (`gradlew` und `gradle-wrapper.jar`). Android Studio kann die Gradle-Distribution einrichten; alternativ Wrapper mit einer lokal installierten Gradle-Version erzeugen.
2. **Standard-Android-Emulator** mit API-Level >=28 starten, Backend auf dem Host laufen lassen.
3. Debug-Build ausführen: `BuildConfig.FEED_URL` ist auf `http://10.0.2.2:8000/feed` gesetzt. `10.0.2.2` bezeichnet im Standard-Emulator den Hostrechner, **nicht** `localhost` des Emulators.
4. Nach erstem Laden Netz deaktivieren: lokale Textdaten stehen weiter in SQLite. Bei geringer geschätzter Bandbreite blendet der Adapter Bilder aus und stößt keine Bild-HTTP-Anfragen an.
5. Wieder mit WLAN verbinden: `JobScheduler` kann den periodischen Job unter geeigneten Bedingungen ausführen. Er startet nicht garantiert sofort; das Betriebssystem wählt den konkreten Termin.

**Hinweis zum realen Smartphone:** `10.0.2.2` funktioniert nur im Android-Emulator. Für ein reales Gerät Feed-URL auf Host-IP im gemeinsamen Netz oder besser auf eine HTTPS-Serveradresse ändern. Release verwendet bewusst `https://example.invalid/feed` als Platzhalter; vor einer Veröffentlichung einen gültigen HTTPS-Endpunkt eintragen.

## REST-Beispiel

```json
{"articles":[{"id":"tech-001","title":"Neue Entwicklungen bei KI-Chips","summary":"Ein Überblick über effizientere Hardware für lokale KI-Anwendungen.","image_url":"https://picsum.photos/id/0/640/360"}]}
```

## MAPE-K

- **Monitor** – `CONNECTIVITY_ACTION` in einer laufzeitregistrierten BroadcastReceiver-Instanz sowie `ConnectivityManager.NetworkCallback`.
- **Analyze** – `NET_CAPABILITY_VALIDATED` und geschätzte `linkDownstreamBandwidthKbps` (Demo-Schwelle 1.500 kbit/s, kein echter Speedtest).
- **Plan** – je nach Kontext Bilder aktivieren oder reduzieren.
- **Execute** – `FeedAdapter` bindet nur bei guter Bandbreite `NetworkImageView` an `ImageLoader`.
- **Knowledge** – SQLite enthält den letzten erfolgreich gespeicherten REST-Snapshot; der aktive Kontext wird in der Activity gehalten.

Der Volley-HTTP-Cache ist **nicht** die garantierte Offline-Persistenz; hierfür ist ausschließlich SQLite zuständig. Bilder werden bewusst nicht in SQLite gespeichert und sind offline daher nicht garantiert verfügbar. Externe Bild-URLs sind Dummy-Bilder, keine zugesicherte Bildquelle. Der Server liefert Newsletter-*Metadaten*, kein Scraping.

## Randbedingungen

- **Keine Wake Locks in App-Code**: Der JobScheduler verwaltet die notwendigen Systemressourcen selbst.
- **Keine Busy-Wait-Schleifen**: Receiver, Callback, Volley und `JobScheduler` sind ereignisgesteuert.
- **Keine SQLite-Abfragen auf dem Hauptthread**: Java `Executors.newSingleThreadExecutor()`.
- **JobScheduler-WLAN-Constraint**: ab API 28 per `setRequiredNetwork(NetworkRequest)`; im Service wird zusätzlich die aktive Standardroute geprüft, da Volley über diese kommuniziert.
- **Demo-Cache**: Responses werden 5 Minuten HTTP-gecached; ein manueller Reload innerhalb dieser Zeit kann daher einen Cachetreffer statt einer neuen Serveranfrage liefern.
- **Datenmigration**: Das `onUpgrade`-Schema löscht die Demo-Daten. Produktiv wären Schema-Migrationen erforderlich.
