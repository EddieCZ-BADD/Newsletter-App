"""Dummy-REST-Proxy: extrahierte Newsletter-Metadaten als Feed-JSON.

In der Extraktionsarchitektur ersetzt dieser Endpunkt eine direkte Abfrage
externer Newsletter-Quellen durch einen stabilen, kompakten REST-Vertrag.
"""

from fastapi import FastAPI, Response

app = FastAPI(title="Adaptiver Tech-Feed – Server-Proxy", version="1.0.0")

# Stabile IDs sind wichtig: SQLite verwendet sie als Primärschlüssel.
DUMMY_ARTICLES = [
    {
        "id": "tech-001",
        "title": "Neue Entwicklungen bei KI-Chips",
        "summary": "Ein Überblick über effizientere Hardware für lokale KI-Anwendungen.",
        "image_url": "https://picsum.photos/id/0/640/360",
    },
    {
        "id": "tech-002",
        "title": "Sicherere Software-Updates",
        "summary": "Warum reproduzierbare Builds für die Lieferkette relevant sind.",
        "image_url": "https://picsum.photos/id/1/640/360",
    },
    {
        "id": "tech-003",
        "title": "Edge Computing im Alltag",
        "summary": "Gerätenahe Verarbeitung reduziert Latenz und Netzwerkverkehr.",
        "image_url": "https://picsum.photos/id/2/640/360",
    },
]


@app.get("/feed")
def get_feed(response: Response) -> dict:
    """REST/JSON: Volley darf die Antwort fünf Minuten transparent cachen."""
    response.headers["Cache-Control"] = "public, max-age=300"
    return {"articles": DUMMY_ARTICLES}


if __name__ == "__main__":
    import uvicorn

    uvicorn.run(app, host="0.0.0.0", port=8000)
